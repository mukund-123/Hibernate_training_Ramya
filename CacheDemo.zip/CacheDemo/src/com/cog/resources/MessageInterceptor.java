package com.cog.resources;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Iterator;

import org.hibernate.EmptyInterceptor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.type.Type;

import com.cog.entities.CTSMessage;
import com.cog.entities.MessageTracker;

public class MessageInterceptor extends EmptyInterceptor{
	private String operation;
    private boolean isMainEntity;

	@Override
	public int[] findDirty(Object entity, Serializable id, Object[] currentState, Object[] previousState,
			String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("Flushing......");
		return super.findDirty(entity, id, currentState, previousState, propertyNames, types);
	}

	@Override
	public void onDelete(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("On Delete......");
		//super.onDelete(entity, id, state, propertyNames, types);
	}

	@Override
	public boolean onLoad(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("OnLoad......");
		return false;
		//return super.onLoad(entity, id, state, propertyNames, types);
	}

	@Override
	public boolean onSave(Object entity, Serializable id, Object[] state, String[] propertyNames, Type[] types) {
		// TODO Auto-generated method stub
		System.out.println("Saving........");
		
		if(entity instanceof CTSMessage)
		{
			isMainEntity=true;
			operation="INSERT";
			return true;
			
		}
		  isMainEntity = false;
    	  return false;
		//return super.onSave(entity, id, state, propertyNames, types);
	}

	@Override
	public void postFlush(Iterator entities) {
		// TODO Auto-generated method stub
		System.out.println("PostFlushing......");
		if(isMainEntity)
		{
			SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
			Session session=sessionFactory.openSession();
			session.getTransaction().begin();
			MessageTracker messageTracker=new MessageTracker();
			messageTracker.setActivity(operation);
			messageTracker.setCreatedAt(Calendar.getInstance().getTime());
			session.save(messageTracker);
			session.getTransaction().commit();
			
			
		}
		isMainEntity=false;
		
		
		//super.postFlush(entities);
	}

	@Override
	public void preFlush(Iterator entities) {
		System.out.println("PreFlushing......");
		// TODO Auto-generated method stub
		//super.preFlush(entities);
	}

}
