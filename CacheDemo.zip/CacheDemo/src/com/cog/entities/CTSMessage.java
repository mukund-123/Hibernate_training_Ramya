package com.cog.entities;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;
@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)

@Entity
@Table(name="CTSMessage")
public class CTSMessage {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="MessageId")
	private int messageId;
    @Column(name="Description", nullable=false, length=100)
	private String description;
	public int getMessageId() {
		return messageId;
	}
	public void setMessageId(int messageId) {
		this.messageId = messageId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
}
