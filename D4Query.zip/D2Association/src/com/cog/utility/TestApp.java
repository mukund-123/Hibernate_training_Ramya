package com.cog.utility;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.cog.dao.DaoManager;
import com.cog.entity.Address;
import com.cog.entity.Author;
import com.cog.entity.Book;
import com.cog.entity.Course;
import com.cog.entity.Customer;
import com.cog.entity.Player;
import com.cog.entity.Team;
import com.cog.entity.Trainee;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		DaoManager dm = new DaoManager();
		/*
		Address add=new Address();
		add.setStreet("Big Street");
		add.setCity("Chennai");
		Customer cus=new Customer();
		cus.setName("Name2");
		cus.setDob(new Date(116,1,1));
		dm.AddCusAddress(cus, add);
		
		Iterator itr = dm.getAll().iterate();
		System.out.println("CUSTOMERID"+"\t"+"NAME"+"\t"+"CITY"+"\t"+"STREET");
		while (itr.hasNext()){
			Object[] obj=(Object[])itr.next();
			System.out.println(obj[0]+"\t"+obj[1]+"\t"+obj[2]+"\t"+obj[3]);
		}
		
	//	System.out.println("going to update city in the address");
	//	dm.updateCustomer(1);
		System.out.println("DONE");
		
	
		*/
		
		
		//*********BIDIRECTONAL**************/
		/*
		Book bk = new Book();
		bk.setBname("REST");
		bk.setDOB(new Date(97,3,5));
		Author au = new Author();
		au.setAname("John");
		dm.AddBook_Author(bk, au);
	
		
		
		
		Team t1=new Team();
		Player py=new Player();
		List<Player> plist=new ArrayList<Player>();
		t1.setTName("aaa");
		//t1.setPlayer(player);
		py.setPName("bbb");
		py.setTeam(t1);
		plist.add(py);
		
		py.setPName("ccc");
		py.setTeam(t1);
		plist.add(py);
		*/
		
		/*
		t1.setTName("RCB");
		py.setPName("Virat");
		py.setTeam(t1);
		plist.add(py);
		
		dm.AddTeam_Player(t1, plist);
		//to get all team players
		
		for(Team tt:dm.getAllTeam_Players())
		{
			System.out.println(tt.getTName());
			for(Player p1:tt.getPlayer())
			{
				System.out.print("\t"+p1.getPName());
			}
		}
		
		
				
		
		
		
		
		List<Trainee> tlist=new ArrayList<Trainee>();
		List<Course> clist=new ArrayList<Course>();
		Trainee tn=new Trainee();
		tn.setTName("Ramya");
		tlist.add(tn);
		Trainee tn1=new Trainee();
		tn1.setTName("Raji");
		tlist.add(tn1);
		Trainee tn2=new Trainee();
		tn2.setTName("Krish");
		tlist.add(tn2);
		
		Course cr=new Course();
		cr.setCName("Java");
		clist.add(cr);
		Course cr1=new Course();
		cr1.setCName("Hibernate");
		clist.add(cr1);
		Course cr2=new Course();
		cr2.setCName("Rest");
		clist.add(cr2);
		//cr2.setTlist(tlist);
		//clist.add(e)
		dm.AddTrainee_Course(tlist, clist);
		
		*/
		
		
		
		System.out.println("DONE!!");
		
		
		
	}
	
	

}
