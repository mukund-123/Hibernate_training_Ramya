package com.cog.utility;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;

import com.cog.dao.EventManager;
import com.cog.entity.Event;
import com.cog.entity.Participants;
import com.cog.entity.Player;
import com.cog.entity.Room;
import com.cog.entity.Team;

public class TestApp1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EventManager em=new EventManager();
	
		Event event=new Event();
		event.setEventName("Session");
		Room room =new Room();
		room.setCapacity(10);
		room.setLocation("BANGALORE");
		em.AddRoom_Event(room, event);


		
		
		Room r1=new Room();
		Participants py=new Participants();
		List<Participants> plist=new ArrayList<Participants>();
			
		r1.setCapacity(10);
		r1.setLocation("TN");
		//t1.setPlayer(player);
	
		py.setPname("Raja");
		py.setRoom(r1);
		
		plist.add(py);
		py=new Participants();
		py.setPname("Jeni");
		py.setRoom(r1);
		
		plist.add(py);
		
		em.AddRoom_participants(r1, plist);
		
		
	}
	
	

}
