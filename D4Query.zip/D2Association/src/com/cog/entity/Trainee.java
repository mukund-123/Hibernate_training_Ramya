package com.cog.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="Trainee")
public class Trainee {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Trainee_Id")
	private int TId;
	@Column(name="Trainee_Name")
	private String TName;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="Trainee_Course",joinColumns={@JoinColumn(name="Trainee_Id")},inverseJoinColumns={@JoinColumn(name="Course_Id")})
	private List<Course> clist;
	
	public int getTId() {
		return TId;
	}
	public void setTId(int tId) {
		TId = tId;
	}
	public String getTName() {
		return TName;
	}
	public void setTName(String tName) {
		TName = tName;
	}
	public List<Course> getClist() {
		return clist;
	}
	public void setClist(List<Course> clist) {
		this.clist = clist;
	}
	
	
	
}
