package com.cog.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Room1")
public class Room {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="RoomNo")
	private int roomNo;
	@Column(name="Location")
	private String location;
	@Column(name="capacity")
	private int capacity;
	@OneToOne
	@JoinColumn(name="Room_event")
	private Event event;
	@OneToMany(mappedBy="room",cascade=CascadeType.ALL)
	private List<Participants> par;
	
	public List<Participants> getPar() {
		return par;
	}
	public void setPar(List<Participants> par) {
		this.par = par;
	}
	public Event getEvent() {
		return event;
	}
	public void setEvent(Event event) {
		this.event = event;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
}
