package com.cog.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="CTS_Employee")
@PrimaryKeyJoinColumn(name="adhar_Id",referencedColumnName="AatharCNo")
public class Employee extends Person{


	@Column(name="EmpNo")
	private int eNo;
	private String project;
	private String location;
	
	
	public int geteNo() {
		return eNo;
	}
	public void seteNo(int eNo) {
		this.eNo = eNo;
	}
	public String getProject() {
		return project;
	}
	public void setProject(String project) {
		this.project = project;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	
	
}
