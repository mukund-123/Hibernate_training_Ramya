package com.cog.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
//@DiscriminatorValue(value="CreditCardObj")
@Table(name="Ccard")
public class CreditCard extends Payment{
	@Column(name="CreditCardNo")
	private long CCardNo;
	@Column(name="CVV")
	private int CVV;
	@Column(name="CreditCardName")
	private String CName;
	@Temporal(TemporalType.DATE)
	@Column(name="CreditCardEXP")
	private Date CEXP;
	@Column(name="EMI")
	private boolean EMI;
	
	
	public long getCCardNo() {
		return CCardNo;
	}
	public void setCCardNo(long cCardNo) {
		CCardNo = cCardNo;
	}
	public int getCVV() {
		return CVV;
	}
	public void setCVV(int cVV) {
		CVV = cVV;
	}
	public String getCName() {
		return CName;
	}
	public void setCName(String cName) {
		CName = cName;
	}
	public Date getCEXP() {
		return CEXP;
	}
	public void setCEXP(Date cEXP) {
		CEXP = cEXP;
	}
	public boolean isEMI() {
		return EMI;
	}
	public void setEMI(boolean eMI) {
		EMI = eMI;
	}


}
