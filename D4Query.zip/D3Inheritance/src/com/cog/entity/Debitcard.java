package com.cog.entity;

import java.util.Date;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
//@DiscriminatorValue(value="DebitCardObj")
@Table(name="Dcard")
public class Debitcard extends Payment{

	private long DCardNo;
	private int dvv;
	private String DName;
	@Temporal(TemporalType.DATE)
	private Date DEXP;
	
	public long getDCardNo() {
		return DCardNo;
	}
	public void setDCardNo(long dCardNo) {
		DCardNo = dCardNo;
	}
	public int getDvv() {
		return dvv;
	}
	public void setDvv(int dvv) {
		this.dvv = dvv;
	}
	public String getDName() {
		return DName;
	}
	public void setDName(String dName) {
		DName = dName;
	}
	public Date getDEXP() {
		return DEXP;
	}
	public void setDEXP(Date dEXP) {
		DEXP = dEXP;
	}
	
}
