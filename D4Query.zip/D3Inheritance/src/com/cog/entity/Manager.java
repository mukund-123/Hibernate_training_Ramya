package com.cog.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Table;


@Entity
@Table(name="CTS_Manager")
//@PrimaryKeyJoinColumn(name="Emp_Id",referencedColumnName="eNo")
//@PrimaryKeyJoinColumn(name="adhar_Id",referencedColumnName="aCardNo")
public class Manager extends Employee{

	private int NOP;
	@Column(name="approval")
	private boolean lapp;
	
	public int getNOP() {
		return NOP;
	}
	public void setNOP(int nOP) {
		NOP = nOP;
	}
	public boolean isLapp() {
		return lapp;
	}
	public void setLapp(boolean lapp) {
		this.lapp = lapp;
	}
	

}
