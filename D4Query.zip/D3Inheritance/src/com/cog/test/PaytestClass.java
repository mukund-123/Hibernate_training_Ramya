package com.cog.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.PayManager;
import com.cog.entity.Address;
import com.cog.entity.Employee;
import com.cog.entity.Manager;
import com.cog.entity.Payment;
import com.cog.entity.Person;

public class PaytestClass {
	private PayManager pmgr;
	@Before
	public void setUp() throws Exception {
		pmgr = new PayManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		
		/*
		Payment pm = new Payment();
		pm.setCustomerId(1);
		pm.setAmount(1000);
		pm.setDOT(new Date(115,2,3));
		assertTrue(pmgr.AddPayment(pm));
	
		
		Person per=new Person();
		per.setaCardNo(999);
		Address add= new Address();
        add.setStreetName("New_Street");
        add.setCity("CHENNAI");
        add.setState("TN");
        
		per.setAddress(add);
		per.setName("Ramya");
		assertTrue(pmgr.AddPerson(per, add));
		
					
		Employee emp=new Employee();
		emp.seteNo(12342);
		emp.setLocation("CHENNAI");
		emp.setProject("Ally");
		emp.setName("TEst1");
		Address add= new Address();
        add.setStreetName("New_Street1");
        add.setCity("CHENNAI");
        add.setState("TN");
        
		emp.setAddress(add);
		
		assertTrue(pmgr.AddEmployee(emp,add));
		
		*/
		
		Manager mgr=new Manager();
		mgr.setLapp(true);
		mgr.setNOP(2);
		//Employee emp=new Employee();
		mgr.seteNo(1231231);
		mgr.setLocation("CHENNAI ONE");
		mgr.setProject("CDP");
		mgr.setName("Test11");
		Address add= new Address();
        add.setStreetName("New_Street12");
        add.setCity("TRICHY");
        add.setState("TN");
        mgr.setAddress(add);
		
		
		
		assertTrue(pmgr.AddManager(mgr,add));
		
		
		
	}

	
	
}
