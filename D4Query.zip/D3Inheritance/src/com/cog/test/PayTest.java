package com.cog.test;

import static org.junit.Assert.*;

import java.util.Date;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.PayManager;
import com.cog.entity.CreditCard;
import com.cog.entity.Debitcard;
import com.cog.entity.Payment;

public class PayTest {

	private PayManager pmgr;
	@Before
	public void setUp() throws Exception {
	pmgr = new PayManager();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void PayObjtest() {
		/*
		Payment pm = new Payment();
		pm.setAmount(1000);
		pm.setDOT(new Date(115,2,3));
		assertTrue(pmgr.AddPayment(pm));
		
		CreditCard cc=new CreditCard();
		cc.setCCardNo(123456);
		cc.setAmount(1200);
		cc.setCEXP(new Date(115,2,3));
		cc.setEMI(true);
		cc.setCVV(200);
		cc.setCName("Master card");
		cc.setDOT(new Date(114,1,9));
		assertTrue(pmgr.AddCreditPayment(cc));
		*/
	
		/*
		Debitcard dc = new Debitcard();
		dc.setAmount(2000);
		dc.setDOT(new Date(115,3,4));
		dc.set
		
		
		assertTrue(pmgr.AddPayment(pm));
		*/
		
	}

	
	
}
