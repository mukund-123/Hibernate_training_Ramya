package com.cog.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entity.Address;
import com.cog.entity.CreditCard;
import com.cog.entity.Debitcard;
import com.cog.entity.Employee;
import com.cog.entity.Manager;
import com.cog.entity.Payment;
import com.cog.entity.Person;
import com.cog.resources.HibernateUtil;

public class PayManager {

	private SessionFactory factory;
	private Session session;
	private boolean status;
	public PayManager()
	{
		factory=HibernateUtil.GetFactory();
	}
	
	public boolean AddPayment(Payment pay)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(pay);
			session.getTransaction().commit();
			status=true;
		}catch(HibernateException he)
		{
			session.getTransaction().rollback();
			status=false;
		}
		
		session.close();
		return status;
	}
	
	public boolean AddCreditPayment(CreditCard ccard)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(ccard);
			session.getTransaction().commit();
			status=true;
		}catch(HibernateException he)
		{
			session.getTransaction().rollback();
			status=false;
		}
		
		session.close();
		return status;
	}
	
	public boolean AddDebitPayment(Debitcard dcard)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(dcard);
			session.getTransaction().commit();
			status=true;
		}catch(HibernateException he)
		{
			session.getTransaction().rollback();
			status=false;
		}
		
		session.close();
		return status;
	}
	
	
	public boolean AddPerson(Person per,Address add)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(add);
			per.setAddress(add);
			session.save(per);
			session.getTransaction().commit();
			status=true;
		}catch(HibernateException he)
		{
			session.getTransaction().rollback();
			status=false;
		}
		
		session.close();
		return status;
	}
	
	
	public boolean AddEmployee(Employee emp,Address add)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(add);
			emp.setAddress(add);
			session.save(emp);
			session.getTransaction().commit();
			status=true;
		}catch(HibernateException he)
		{
			session.getTransaction().rollback();
			status=false;
		}
		
		session.close();
		return status;
	}
	
	public boolean AddManager(Manager mgr,Address add)
	{
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(add);
			mgr.setAddress(add);
			session.save(mgr);
			session.getTransaction().commit();
			status=true;
		}catch(HibernateException he)
		{
			session.getTransaction().rollback();
			status=false;
		}
		
		session.close();
		return status;
	}
	
	
	
	public List<Manager> getManager()
	{
		session.beginTransaction();
		return session.createQuery("from Manager").list();
		
	}
}
