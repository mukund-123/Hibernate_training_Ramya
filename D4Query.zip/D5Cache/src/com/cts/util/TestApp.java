package com.cts.util;

import java.util.Locale;

import org.hibernate.Cache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

//import com.cog.entities.CTSMessage;
import com.cts.entity.Location;
import com.cts.resources.HibernateUtil;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory factory=HibernateUtil.getSessionFactory();
		System.out.println("openSession start");
		Session session=factory.openSession();
		System.out.println("openSession end");
		System.out.println("beginTransaction start");
		session.beginTransaction();
		System.out.println("beginTransaction end");
		try{
			Location lon=new Location();
			lon.setLocatioNanme("CHENNAI");
			session.save(lon);
			session.getTransaction().commit();
			
		}catch(HibernateException he)
		{
			session.getTransaction().rollback();
		}
	
		/*
		//Cache
		
		System.out.println("retrieve from first level cache.....");
		Location location= (Location) session.load(Location.class, 2);
		System.out.println(location.getLocatioNanme());
		//System.out.println(location.getDescription());
		System.out.println("Before Clear \t"+session.contains(location));
		session.evict(location);
		System.out.println("After evict Clear"+session.contains(location));
		System.out.println("retrieve from second level cache.....");
		Cache cache = factory.getCache();
		System.out.println("Second Value\t"+cache.containsEntity(Location.class, 2));
		location=(Location) session.load(Location.class, 2);
		System.out.println(location.getLocatioNanme());
		//System.out.println(session.contains(location));
		 * 
		 */
		session.close();
	}

}
