package com.cts.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="LocationTracker")
public class LocationTracker {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private int trackerId;
	private String activity;
	@Temporal(TemporalType.DATE)
	private Date DOA;
	
	public int getTrackerId() {
		return trackerId;
	}
	public void setTrackerId(int trackerId) {
		this.trackerId = trackerId;
	}
	public String getActivity() {
		return activity;
	}
	public void setActivity(String activity) {
		this.activity = activity;
	}
	public Date getDOA() {
		return DOA;
	}
	public void setDOA(Date dOA) {
		DOA = dOA;
	}
	
	
}
