package com.cts.entity;

import javax.persistence.Cacheable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

@Cacheable
@Cache(usage=CacheConcurrencyStrategy.READ_ONLY)


@Entity
@Table(name="CTS_NewLocation")
public class Location {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int locationId;
	
	private String locatioNanme;
	public int getLocationId() {
		return locationId;
	}
	public void setLocationId(int locationId) {
		this.locationId = locationId;
	}
	public String getLocatioNanme() {
		return locatioNanme;
	}
	public void setLocatioNanme(String locatioNanme) {
		this.locatioNanme = locatioNanme;
	}
	
}
