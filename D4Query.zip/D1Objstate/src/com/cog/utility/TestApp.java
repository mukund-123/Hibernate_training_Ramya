package com.cog.utility;

import java.util.Scanner;

import com.cog.dao.EventManager;
import com.cog.dao.RoomManager;
import com.cog.entity.Event;
import com.cog.entity.EventKey;

import com.cog.entity.Room;

public class TestApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		RoomManager rmgr=new RoomManager();
	
		Room rm=new Room();
		rm.setCapacity(100);
		rm.setLocation("ASV Suntech Park Cognizant");
		rm.setProj_AVL(true);
		rm.setSys_AVL(true);
		if(rmgr.AddRoom(rm))
			System.out.println("Record added!!!");
	
	
		/*
		for(Room room:rmgr.GetAllRooms())
		{
			System.out.print(room.getRoomNo()+"\t");
			System.out.print(room.getCapacity()+"\t");
			System.out.print(room.getLocation()+"\n");
		}
	*/
		/*
		if(rmgr.UpdateRoom(1))
			System.out.println("Record Updated");
		
		
		if(rmgr.deleteRoom(Rno))
			System.out.println("Record Deleted");
		
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		System.out.println("enter room no1");
		int Rno1=scan.nextInt();
		System.out.println("enter room no2");
		int Rno2=scan.nextInt();
		rmgr.roomEvit_Clear(Rno1, Rno2);
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!");
		
		rmgr.SessionClose(1);
		System.out.println("CLOSED------------------>>>>");
	
		EventManager eventmanager=new EventManager();
		EventKey eventkey=new EventKey();
		eventkey.setEventId(2);
		eventkey.setTrainerId(234);
		Event event=new Event();
		event.setEventId(eventkey);
		event.setDuration(9);
		event.setEventName("Hiber Train");
		event.setLocation("Chennaiii");
		eventmanager.AddEvent(event);
			*/
	
		
		
	}
	
	
}
