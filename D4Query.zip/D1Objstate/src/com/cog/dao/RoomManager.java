package com.cog.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cog.entity.Room;
import com.cog.resources.HibernateUtil;

@SuppressWarnings("unused")
public class RoomManager {

	private SessionFactory factory;
	private Session session;
	public RoomManager()
	{
		factory = HibernateUtil.GetFactory();
	}
	
	public boolean AddRoom(Room room)
	{
		boolean status=false;
		session=factory.openSession();
		session.beginTransaction();
		try
		{
			session.save(room);
			session.getTransaction().commit();
			status=true;
		}
		catch(HibernateException ex){
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	@SuppressWarnings("unchecked")
	public List<Room> GetAllRooms()
	{
		
		session=factory.openSession();
		return session.createQuery("from Room").list();
	}
	
	public boolean UpdateRoom(int roomNo)
		{
		boolean status=false;
		Room rm= (Room) session.get(Room.class, roomNo);
		rm.setCapacity(66);
		rm.setSys_AVL(false);
		session.beginTransaction();
		try{
			//session.update(rm);
			session.getTransaction().commit();
			status = true;
		}catch(HibernateException ex1)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
	}
	
	public boolean deleteRoom(int roomNo){
		boolean status=false;
		Room rm= (Room) session.get(Room.class, roomNo);
		session.beginTransaction();
		try{
			session.delete(rm);
			session.getTransaction().commit();
			status = true;
		}catch(HibernateException ex1)
		{
			session.getTransaction().rollback();
		}
		session.close();
		return status;
			
		}
public boolean roomEvit_Clear(int roomNo1,int roomNo2)
{
	boolean status=false;
	session=factory.openSession();
	Room o1=(Room)session.get(Room.class, roomNo1);
	Room o2=(Room)session.get(Room.class, roomNo2);
	//Modify O1 & O2
	session.evict(o2);//O2 detached from the session
	//session.clear();
	session.beginTransaction();
	o1.setCapacity(69);
	o2.setCapacity(99);
	session.getTransaction().commit();
	//System.out.println("doneeeeeeeee");
	status = true;
	session.close();
	return status;
	
	
}

public boolean SessionClose(int RoomNo)
{
	boolean status=false;
	session=factory.openSession();
	Room rm= (Room) session.get(Room.class, RoomNo);
	session.beginTransaction();
	session.close();
	
	rm.setCapacity(3333);
	
	
	Session session1=factory.openSession();
	session.beginTransaction();
	Room rm1= (Room) session1.get(Room.class, RoomNo);
	session1.merge(rm);
	session1.getTransaction().commit();
	status = true;
	//session.close();
	return status;
}

}