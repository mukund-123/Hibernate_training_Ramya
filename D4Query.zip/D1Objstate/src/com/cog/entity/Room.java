package com.cog.entity;

public class Room {

	private int roomNo;
	private String location;
	private int capacity;
	private boolean sys_AVL;
	private boolean proj_AVL;
	
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public boolean isSys_AVL() {
		return sys_AVL;
	}
	public void setSys_AVL(boolean sys_AVL) {
		this.sys_AVL = sys_AVL;
	}
	public boolean isProj_AVL() {
		return proj_AVL;
	}
	public void setProj_AVL(boolean proj_AVL) {
		this.proj_AVL = proj_AVL;
	}
	
	
}
