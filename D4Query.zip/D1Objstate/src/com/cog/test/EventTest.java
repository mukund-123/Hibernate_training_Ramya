package com.cog.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cog.dao.EventManager;
import com.cog.entity.Event;
import com.cog.entity.EventKey;

public class EventTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void test() {
		EventManager eventmanager=new EventManager();
		EventKey eventkey=new EventKey();
		eventkey.setEventId(3);
		eventkey.setTrainerId(999);
		Event event=new Event();
		event.setEventId(eventkey);
		event.setDuration(8);
		event.setEventName("Hibernate Train");
		event.setLocation("ASV");
		assertTrue(eventmanager.AddEvent(event));
		
	}

}
