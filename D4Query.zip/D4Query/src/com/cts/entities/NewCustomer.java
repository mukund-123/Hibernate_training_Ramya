package com.cts.entities;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="CTS_NEWCUSTOMER")

public class NewCustomer extends Customer{

	
}
