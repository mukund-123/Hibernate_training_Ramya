package com.cts.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;


@Entity
@Table(name="CTS_Customer")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Customer {

	@Id
	//@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CUST_ID")
	
	private int customerId;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerNAme() {
		return customerNAme;
	}
	public void setCustomerNAme(String customerNAme) {
		this.customerNAme = customerNAme;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	
	@Column(name="CUST_Name")
	private String customerNAme;
	@Column(name="CUST_ADDRESS")
	private String Address; 
}
