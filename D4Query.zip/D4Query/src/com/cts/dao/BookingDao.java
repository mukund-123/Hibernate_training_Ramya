package com.cts.dao;

import java.util.List;
import java.util.Random;

//import javax.persistence.Query;







import org.hibernate.Cache;
import org.hibernate.Criteria;
//import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.cts.entities.Booking;
import com.cts.entities.Customer;
import com.cts.entities.Event;
import com.cts.entities.Location;
import com.cts.resources.HibernateUtil;

public class BookingDao {

	private SessionFactory factory;
	private Session session;
	private Location location;
	private Event event;
	private Customer customer;
	
	public BookingDao()
	{
		factory=HibernateUtil.GetFactory();
	}
	
	public boolean InsertLocations()
	{
		boolean status=false;
		//factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		session.beginTransaction();
		Random random=new Random();
		Location location=null;
		try{
			
			for(int i=0;i<100;i++)
			{
				location=new Location();
				location.setLocationName("CTS"+random.nextInt());
				session.save(location);
				
				
				if(i%20==0)
				{
					session.flush();
					session.clear();
				}
				
				
				status=true;
			}
			session.getTransaction().commit();
		}catch(HibernateException e)
		{
			session.getTransaction().rollback();
		}
		
		return status;
	}
	
	/*****************Need to check */
	
	public List<Location> GetLocationByName(){
		
		session=factory.openSession();
		//Query query =session.createQuery("from Location where locationName=?");
		//Query query =session.getNamedQuery("GetLocationByname");-> Named Query
		
		Criteria criteria=session.createCriteria(Location.class);
		criteria.add(Restrictions.gt("locationId",90));
		//criteria.add(Restrictions.like("locationName", "CTS%"));
		
		//return (Location)criteria.list().get(0);
		return criteria.list();
	}
	
	
	
public long GetLocationCount(){
		
		session=factory.openSession();
		Query query =session.createQuery("select count(loc.locationName) from Location loc");
		//Query query =session.createQuery("select count(Location.locationName) from Location");
		return (long) query.list().get(0);
	}

public int GetMaxLocationId(){
	
	session=factory.openSession();
	Query query =session.createQuery("select max(loc.locationId) from Location loc");
	
	return (int) query.list().get(0);
}

public int SecondLastLocation()
{
	session=factory.openSession();
	Query query =session.createQuery("select max(l.locationId) from Location l where l.locationId < (select max(loc.locationId) from Location loc)");
	return (int)query.list().get(0);
}

public List<Location> sortLocation(){
	
	session=factory.openSession();
	Query query =session.createQuery("from Location loc order by loc.locationName desc");
	
	return query.list();
}

	public int InsertLocation(Location loc)
	{
		
		location=loc;
		int pk=0;
		
		session=factory.openSession();
		session.beginTransaction();
		try{
			pk=(int)session.save(location);
			
			session.getTransaction().commit();
			return pk;
		}catch(HibernateException he){
			session.getTransaction().rollback();
		}
		
		
		return pk;
	}
	
	public void InsertEvent(Event eve,int locationId)
	{
		event=eve;
		session=factory.openSession();
		Location result=(Location)session.get(Location.class, locationId);	
		session.beginTransaction();
		try{
			
			event.setLocation(result);
			session.persist(event);
			session.getTransaction().commit();
		}catch(HibernateException he){
			session.getTransaction().rollback();
		}
		
		
		
	}
	
	
	public void InsertCustomer(Customer cus)
	{
		
		
	}
	public void InsertBooking(Booking bk)
	{
		
	}
	
	public boolean TestsecondLevelCache(){
		
		//factory=HibernateUtil.GetFactory();
		session=factory.openSession();
		Location locn=(Location) session.load(Location.class,91);
		System.out.println("Check First level cache...");
		System.out.println("Status of Object"+session.contains(locn));
		session.evict(locn);
		System.out.println("checking 1st level cache after evict");
		System.out.println("Status of Object"+session.contains(locn));
		Cache cache=factory.getCache();
		System.out.println("Check Second level cache after evict...");
		System.out.println("Status of Object"+cache.containsEntity(Location.class, 91));
		return cache.containsEntity(Location.class, 91);
	}
	
	
	
	
	
	
	
	
}








