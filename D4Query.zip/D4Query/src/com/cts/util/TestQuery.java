package com.cts.util;

import org.hibernate.Query;

import com.cts.dao.BookingDao;
import com.cts.entities.Location;

public class TestQuery {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BookingDao bdao=new BookingDao();
		//System.out.println(bdao.GetLocationCount());
		//System.out.println(bdao.GetMaxLocationId());
		/*
		for(Location loc:bdao.sortLocation())
		{
			System.out.println(loc.getLocationName());
		
	}
	*/
		//System.out.println(bdao.SecondLastLocation());
	
/*
		Location loc =bdao.GetLocationByName("CTS710509076");
		System.out.println(loc.getLocationId());
		
	
		
		
		for(Location loc:bdao.GetLocationByName())
		{
			//System.out.println(loc.());
		
	}
		
			*/
		boolean status = bdao.TestsecondLevelCache();
		System.out.println("done!!!!!" +status);
		
	}
}
