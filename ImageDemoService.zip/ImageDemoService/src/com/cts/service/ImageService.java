package com.cts.service;
import java.io.File;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;


@Path("/ImageService")

public class ImageService {

@GET
@Path("/GetImage")
@Produces("image/jpg")
public Response DownloadImage(){
	
	File file=new File("C:/Users/TRAINING/Downloads/download.jpg");
	return Response.status(200).header("Access-Control-Allow-Origin", "*").header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").header("Access-Control-Allow-Credentials","true").header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").header("Access-Control-Max-Age",100052).entity((Object)file).build();
	
	
}

//rest1/ImageService/GetData/123;eventName=training***http://localhost:8080/ImageDemoService/rest1/ImageService/GetData/12345;eventName=training

@GET
@Path("/GetData/{eventId}")
public Response getData(@PathParam("eventId") int eventId,@MatrixParam("eventName") String eventName){
	
	//File file=new File("C:/Users/Public/Pictures/Sample Pictures/Desert.jpg");
	String data="Recevied"+eventName;
	return Response.ok().entity(data).cookie(new NewCookie("Cookie Response",data)).build();
	//return Response.status(200).header("Access-Control-Allow-Origin", "*").header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").header("Access-Control-Allow-Credentials","true").header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").header("Access-Control-Max-Age",100052).entity(data).build();
	
	
}

}