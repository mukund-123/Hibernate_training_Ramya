package com.cts.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement


public class Employee {

	private int empId;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getSkill() {
		return skill;
	}
	public void setSkill(List<String> skill) {
		this.skill = skill;
	}
	private String name;
	private List<String> skill;
}
