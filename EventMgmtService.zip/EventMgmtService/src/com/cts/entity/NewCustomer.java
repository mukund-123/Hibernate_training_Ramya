package com.cts.entity;

public class NewCustomer extends Customer{
	

}
