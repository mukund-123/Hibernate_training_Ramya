package com.cts.services;

import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.cts.entity.Message;

@Path("/ProductSErvice")
public class Productservice {

	@POST
	@Path("/AddProduct")
	
	public Response AddProduct(@FormParam("productId") int Id,@FormParam("name") String Name)
	{
		Message msg=new Message();
		if(Id>0 && Name!=null)
		{
			msg.setStatus("REceived Data"+Id+"\t"+Name);
		}
		
		else
			msg.setStatus("NOTTTTTT REceived Data"+Id+"\t"+Name);
		return Response.status(200).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").header("Access-Control-Max-Age",100052)
				.entity(msg).build();
	}
}
