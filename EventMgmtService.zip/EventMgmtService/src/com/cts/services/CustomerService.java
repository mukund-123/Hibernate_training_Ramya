package com.cts.services;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.cts.dao.CustomerManager;
import com.cts.entity.Customer;
import com.cts.entity.Message;

@Path("/CustomerService")
public class CustomerService {
	
	@Path("/AddCustomer")
	@POST
	@Consumes({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	
	public Response AddCustomerservice(Customer cus){
		boolean status = CustomerManager.AddCustomer(cus);
		Message msg=new Message();
		msg.setStatus("Not Added");
		if(status)
		{
			msg.setStatus("Record Added");
		}
	
		return Response.status(200).header("Access-Control-Allow-Origin", "*").header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").header("Access-Control-Allow-Credentials","true").header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").header("Access-Control-Max-Age",100052).entity(msg).build();	
		
	}
	@Path("/GetCustomer")
	@GET
	@Produces({MediaType.APPLICATION_JSON,MediaType.APPLICATION_XML})
	
	public static Response getCustomers()
	{
	//converting collection to Json
		GenericEntity<List<Customer>> genentity= new GenericEntity<List<Customer>>(CustomerManager.getAll()){};
		return Response.status(200).header("Access-Control-Allow-Origin", "*").header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").header("Access-Control-Allow-Credentials","true").header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").header("Access-Control-Max-Age",100052).entity(genentity).build();	
	}
	
	@Path("/CustomerById/{customerId://d+}")
	@GET
	public  Response getCustomerById(@PathParam("customerId") int customerId)
	{
		
		Customer cus = CustomerManager.getCustomerById(customerId);
		return Response.status(200).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization")
				.header("Access-Control-Allow-Credentials","true")
				.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD")
				.header("Access-Control-Max-Age",100052).entity(cus).build();	
	}
	
}
