package com.cts.services;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Response;

import com.cts.entity.Employee;

@Path("/DateConverter")
public class DateConverter {

	@GET
	@Path("/Format/{year}/{month}/{day}")
	public Response FormatDate(@PathParam("year") int year,@PathParam("month") int month,@PathParam("day") int day)
	{
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy/MMM/dd");
		Date date=new Date(year-1900,month-1,day);
		String fdate=formatter.format(date);
		
		return Response.status(200).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").
				header("Access-Control-Allow-Credentials","true").
				header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").
				header("Access-Control-Max-Age",100052).entity(fdate).build();
	}
	
	//EmployeeInfo?EmployeeId=215330&EmployeeName="Ramya"&SkillSet="java"&SkillSet="UNIX"&SkillSet="PERL"
	
	@GET
	@Path("/EmployeeInfo")

	public Response getEmployeeInfo(@QueryParam("EmployeeId") int EmployeeId,@QueryParam("EmployeeName") String EmployeeName,@QueryParam("SkillSet") List<String>SkillSet)
	{
		Employee emp = new Employee();
		emp.setEmpId(EmployeeId);
		emp.setName(EmployeeName);
		emp.setSkill(SkillSet);
		
		return Response.status(200).header("Access-Control-Allow-Origin", "*")
				.header("Access-Control-Allow-Headers", "origin, content-type, accept, authorization").
				header("Access-Control-Allow-Credentials","true").
				header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS, HEAD").
				header("Access-Control-Max-Age",100052).entity(emp).build();
	}


}

