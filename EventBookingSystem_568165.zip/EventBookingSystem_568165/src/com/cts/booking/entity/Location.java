package com.cts.booking.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

public class Location {
// add the getters and setters for Location entity
// create an association between Location and Event such that they have One to Many unidirectional relationship
// add the collection properties accordingly
	private int locationId;
	private String locationName;
	
	

}
