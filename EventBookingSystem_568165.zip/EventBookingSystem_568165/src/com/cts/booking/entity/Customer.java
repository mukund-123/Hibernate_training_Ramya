package com.cts.booking.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="Customer_CS")
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Customer {	

	//write code for the Customer entity class. 
	//Create Many-to Many association relationship between Customer and Event entity and 
	// hence add the collection properties accordingly
	
	@Id
	@Column(name="cust_id")
	protected int custId;

	@Column(name="cust_Name")
	protected String custName;
	@Column(name="cust_Address")
	protected String custAddress;
	
	
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getCustAddress() {
		return custAddress;
	}

	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}


}
