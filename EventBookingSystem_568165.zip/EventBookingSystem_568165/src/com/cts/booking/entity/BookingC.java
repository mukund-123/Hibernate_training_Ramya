package com.cts.booking.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Embeddable
public class BookingC implements Serializable{
/*
	@OneToOne
	@JoinColumn(name="cust_id")
	private Customer customer;
	@OneToOne
	@JoinColumn(name="event_id")
	private Event event;
	*/
	@Column(name="cust_id")
	private int custId;
	@Column(name="cust_id")
	private int eventId;
	
	public int getCustId() {
		return custId;
	}

	public void setCustId(int custId) {
		this.custId = custId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	
}
